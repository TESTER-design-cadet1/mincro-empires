let isMuted = false;

function startGame() {
  document.getElementById("main-menu").style.display = "none";
  document.getElementById("gameCanvas").style.display = "block";
  log("Game started");
  // Game loop and setup code here...
}

function toggleInstructions() {
  const inst = document.getElementById("instructions");
  inst.style.display = inst.style.display === "none" ? "block" : "none";
}

function toggleMute() {
  isMuted = !isMuted;
  log("Sound " + (isMuted ? "muted" : "unmuted"));
}
