# Micro Empires: World at War

## How to Play
- Open `index.html` in your browser.
- Select a country and start building your empire.
- Use turns to manage economy, military, and diplomacy.

## How to Deploy
1. Upload all files to a GitHub repository.
2. Enable GitHub Pages in the settings.
3. Visit the link GitHub provides to play online.

## Customize
- Add countries in `countries.json`
- Tweak gameplay in `config/game-config.js`
